//
//  FoodItems.swift
//  machine-learning-core-awesomeness
//
//  Created by Caleb Stultz on 9/22/17.
//  Copyright © 2017 Caleb Stultz. All rights reserved.
//

import UIKit

let orange = UIImage(named: "1")!
let waffle = UIImage(named: "2")!
let berries = UIImage(named: "3")!
let skyline = UIImage(named: "4")!
let tomato = UIImage(named: "5")!
let bridge = UIImage(named: "6")!
let brush = UIImage(named: "7")!
let macbook = UIImage(named: "8")!
let strawberry = UIImage(named: "9")!

let foodImages: [UIImage] = [orange, waffle, berries, skyline, tomato, bridge, brush, macbook, strawberry]
